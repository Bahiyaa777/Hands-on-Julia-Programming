// This file is a part of Julia. License is MIT: https://julialang.org/license

@import AppKit;

int main(int argc, const char *argv[]) {
  return NSApplicationMain(argc, argv);
}
