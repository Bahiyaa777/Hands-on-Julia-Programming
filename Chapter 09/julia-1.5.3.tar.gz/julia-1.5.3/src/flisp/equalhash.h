#ifndef JL_EQUALHASH_H
#define JL_EQUALHASH_H

#include "htable.h"

#ifdef __cplusplus
extern "C" {
#endif

HTPROT_R(equalhash)

#ifdef __cplusplus
}
#endif

#endif
