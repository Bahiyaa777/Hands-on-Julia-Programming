// This file is a part of Julia. License is MIT: https://julialang.org/license

@import Foundation;
#import "ExecSandboxProtocol.h"

@interface ExecSandbox : NSObject <ExecSandboxProtocol>
@end
